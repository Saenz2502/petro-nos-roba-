var notas = [];
var i;

for (i = 0; i < 2; i++) {
    notas.push(Number(prompt("añadir notas:" + (i + 1))));
}
var suma = notas.reduce(function(total, cantidad) {
    return total + cantidad
});

var promedio = (suma / (notas.length)).toFixed(1);


var estado;
if (promedio >= 4.0) {
    estado = ("APROBO");
} else {
    estado = ("REPROBO");
}
document.write("Tus notas son: " + notas + "<br>" + "Tu Promedio es: " + promedio + "<br>" + "Estado: " + estado + "<br>");
alert(estado);

